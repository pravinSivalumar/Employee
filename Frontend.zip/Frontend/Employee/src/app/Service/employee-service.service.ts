import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EmployeeServiceService {
  private router: Router;
  private baseUrl = 'http://localhost:8080/details?id=';
  constructor(private http: HttpClient) {}


  getEmployee(id: string): Observable<any> {
    return this.http.get(`${this.baseUrl}${id}`);
  }

  authenticate(username, password) {
    if (username === 'pravinsiva' && password === '123456987') {
      sessionStorage.setItem(username, password);
      return true;
    } else {
      return false;
    }
  }

  isUserLoggedIn() {
    const user = sessionStorage.getItem('pravinsiva');
    console.log(!(user === null));
    return user;
  }

  logout() {
    sessionStorage.removeItem('pravinsiva');
    const user = sessionStorage.getItem('pravinsiva');
    return user;
  }
}

export class Employee {
    employeeId: string;
    fullName: string;
    branch: string;
    salary: string;
    taxAmount: string;
    payAmount: string;
    type: string;
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeServiceService } from '../Service/employee-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username = '';
  password = '';
  invalidLogin = false;

  constructor(private router: Router,private loginService: EmployeeServiceService) { }

  checkLogin(){
    if(this.loginService.authenticate(this.username,this.password)){
      console.log(this.loginService.isUserLoggedIn());
      if(this.loginService.isUserLoggedIn() !== null){
        this.router.navigate(['view']);
        this.invalidLogin = false;
      }
    } else {
      this.invalidLogin = true;
    }
  }

  ngOnInit() {
  }

}

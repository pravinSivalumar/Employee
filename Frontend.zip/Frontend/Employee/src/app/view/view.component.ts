import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from '../Service/employee-service.service';
import { Employee } from '../employee';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  id = '';
  employee: Employee;
  count = 0;

  constructor(private route: ActivatedRoute,private router: Router,private employeeService: EmployeeServiceService) { }

  ngOnInit() {
    this.employee = new Employee();
    //this.id = this.route.snapshot.params['id'];

    this.employeeService.getEmployee(this.id)
      .subscribe(data => {
        console.log(data);
        this.employee = data;
        if( data[0] === undefined && this.count === 1){
          alert("Enter a valid Id");
        }
        this.count = 1;
      }, error => console.log(error));

  }

  logoutS(){
    if(this.employeeService.isUserLoggedIn){
      this.employeeService.logout();
      this.router.navigate(['']);
    }
  }




}

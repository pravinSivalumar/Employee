package com.example.employee;

import com.opencsv.CSVReader;
import com.opencsv.bean.CsvBindByName;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
public class Currency{

    @CsvBindByName(column = "Country")
    private String country;
    @CsvBindByName(column = "Rate")
    private double rate;
    @CsvBindByName(column = "Type")
    private String type;

    public Currency(String country, double rate, String type) {
        this.country = country;
        this.rate = rate;
        this.type = type;
    }



    public Currency() {
    }

    public String getCountry() {
        return country;
    }

    public double getRate() {
        return rate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


}

package com.example.employee;

import java.util.List;

public interface EmployeeInterface {
    List<Employees> getSalary(String id);
}

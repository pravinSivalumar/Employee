package com.example.employee;

import com.opencsv.CSVReader;
import com.opencsv.bean.CsvBindByName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class Employees {
    Currency currency = new Currency();
    @CsvBindByName(column = "Employee")
    private String employeeId;
    @CsvBindByName(column = "Full Name")
    private String fullName;
    @CsvBindByName(column = "Branch")
    private String branch;
    @CsvBindByName(column = "Salary (USD)")
    private double salary;
    private double taxAmount;
    private double payAmount;
    private String type;



    public Employees() {
    }

    public Employees(String employeeId, String fullName, String branch, double salary) {
        this.employeeId = employeeId;
        this.fullName = fullName;
        this.branch = branch;
        this.salary = salary;
    }


    public Employees(String employeeId, String fullName, String branch, double salary, double taxAmount, double payAmount, String type) {
        this.employeeId = employeeId;
        this.fullName = fullName;
        this.branch = branch;
        this.salary = salary;
        this.taxAmount = taxAmount;
        this.payAmount = payAmount;
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }

    public void setPayAmount(double payAmount) {
        this.payAmount = payAmount;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public String getFullName() {
        return fullName;
    }

    public String getBranch() {
        return branch;
    }

    public double getSalary() {
        return salary;
    }

    public double getTaxAmount() {
        return taxAmount;
    }

    public double getPayAmount() {
        return payAmount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employees employees = (Employees) o;
        return Double.compare(employees.salary, salary) == 0 &&
                Double.compare(employees.taxAmount, taxAmount) == 0 &&
                Double.compare(employees.payAmount, payAmount) == 0 &&
                employeeId.equals(employees.employeeId) &&
                fullName.equals(employees.fullName) &&
                branch.equals(employees.branch);
    }

    @Override
    public int hashCode() {
        return Objects.hash(employeeId, fullName, branch, salary, taxAmount, payAmount);
    }

    @Override
    public String toString() {
        return
                "employeeId='" + employeeId + '\'' +
                ", fullName='" + fullName + '\'' +
                ", branch='" + branch + '\'' +
                ", salary="+type+": " + salary +
                ", taxAmount=" +type+": "+ taxAmount +
                ", payAmount=" +type+": "+ payAmount ;
    }
}

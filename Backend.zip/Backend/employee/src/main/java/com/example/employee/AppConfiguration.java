package com.example.employee;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController @CrossOrigin(origins = "http://localhost:4200")
public class AppConfiguration {

    @Autowired
    private EmployeeInterface employeeInterface;

    @GetMapping("/")
    public String hello(){
        return "Hello";
    }

    @GetMapping("/details")
    @ResponseBody
    public List<Employees> getAllEmployees(@RequestParam String id){
        List<Employees> employees = employeeInterface.getSalary(id);
        return employees;
    }

}

package com.example.employee;

import com.opencsv.CSVReader;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
public class Main implements EmployeeInterface {
    ArrayList<Currency> currency_details = new ArrayList<>();
    ArrayList<Employees> employee_details = new ArrayList<>();
    Currency currency = new Currency();
    Employees employees = new Employees();

    public List<Employees> getDetails(){
        try {
            FileReader reader = new FileReader("employee.csv");
            CSVReader br = new CSVReader(reader);
            //br.readAll();
            String[] line;
            br.readNext();
            while((line = br.readNext()) != null) {
                if (!line[0].equals("")) {
                    Employees employees = new Employees(line[0], line[1], line[6], Double.valueOf(line[5]));
                    employee_details.add(employees);
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (com.opencsv.exceptions.CsvException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

//        System.out.println(employee_details);

        return employee_details;
    }


    public List<Currency> getCurrency(){
        try {
            FileReader reader1 = new FileReader("currency.csv");
            CSVReader br1 = new CSVReader(reader1);
            br1.readNext();
            String[] line1;

            while((line1 = br1.readNext()) != null) {
                if (!line1[0].equals("")) {
                    Currency currency = new Currency(line1[0], Double.valueOf(line1[2]), line1[1]);
                    currency_details.add(currency);
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (com.opencsv.exceptions.CsvException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println(currency_details);

        return currency_details;
    }

    @Override
    public List<Employees> getSalary(String id){
        ArrayList<Employees> details = new ArrayList<>();
        double localCurrency;
        for(int i=0;i<employee_details.size();i++){
                if(employee_details.get(i).getEmployeeId().equals(id) && employee_details.get(i).getBranch().equals(new String(" Sri Lanka"))){
                    System.out.println("1");
                    for(int j=0;j<currency_details.size();j++) {
                        if (currency_details.get(j).getCountry().equals(new String("Sri Lanka"))) {
                            localCurrency = currency_details.get(j).getRate() * employee_details.get(i).getSalary();
                            System.out.println(localCurrency);
                            if (localCurrency < 100000) {
                                employees.setTaxAmount(0);
                                employees.setPayAmount(localCurrency);
                                employees.setSalary(localCurrency);
                                employees.setType(currency_details.get(j).getType());
                            } else if (localCurrency >= 100000 && localCurrency < 250000) {
                                employees.setTaxAmount(Math.floor(localCurrency * 0.05));
                                employees.setPayAmount(localCurrency - employees.getTaxAmount());
                                employees.setSalary(localCurrency);
                                employees.setType(currency_details.get(j).getType());
                            } else if (localCurrency >= 250000) {
                                employees.setTaxAmount(Math.floor(localCurrency * 0.10));
                                employees.setPayAmount(localCurrency - employees.getTaxAmount());
                                employees.setSalary(localCurrency);
                                employees.setType(currency_details.get(j).getType());
                                System.out.println(employees.getPayAmount());
                            }
                        }
                    }
                    Employees employeeCorrected = new Employees(employee_details.get(i).getEmployeeId(), employee_details.get(i).getFullName(), employee_details.get(i).getBranch(), employees.getSalary(), employees.getTaxAmount(), employees.getPayAmount(),employees.getType());
                    details.add(employeeCorrected);

                }
                else if(employee_details.get(i).getEmployeeId().equals(id) && employee_details.get(i).getBranch().equals(new String(" India"))){
                    System.out.println("2");
                    for(int j=0;j<currency_details.size();j++) {
                        if (currency_details.get(j).getCountry().equals(new String("India"))) {
                            localCurrency = currency_details.get(j).getRate() * employee_details.get(i).getSalary();
                            if (localCurrency < 100000) {
                                employees.setTaxAmount(0);
                                employees.setPayAmount(localCurrency);
                                employees.setSalary(localCurrency);
                                employees.setType(currency_details.get(j).getType());
                            } else if (localCurrency >= 100000 && localCurrency < 300000) {
                                employees.setTaxAmount(Math.floor(localCurrency * 0.04));
                                employees.setPayAmount(localCurrency - employees.getTaxAmount());
                                employees.setSalary(localCurrency);
                                employees.setType(currency_details.get(j).getType());
                            } else if (localCurrency >= 300000) {
                                employees.setTaxAmount(Math.floor(localCurrency * 0.07));
                                employees.setPayAmount(localCurrency - employees.getTaxAmount());
                                employees.setSalary(localCurrency);
                                employees.setType(currency_details.get(j).getType());
                            }
                        }
                    }
                    Employees employeeCorrected = new Employees(employee_details.get(i).getEmployeeId(), employee_details.get(i).getFullName(), employee_details.get(i).getBranch(), employees.getSalary(), employees.getTaxAmount(), employees.getPayAmount(),employees.getType());
                    details.add(employeeCorrected);

                }
               else if(employee_details.get(i).getEmployeeId().equals(id) && employee_details.get(i).getBranch().equals(new String(" Pakistan"))){
                    System.out.println("3");
                    for(int j=0;j<currency_details.size();j++) {
                        if (currency_details.get(j).getCountry().equals(new String("Pakistan"))) {
                            localCurrency = currency_details.get(j).getRate() * employee_details.get(i).getSalary();
                            if (localCurrency < 500000) {
                                employees.setTaxAmount(Math.floor(0.005 * localCurrency));
                                employees.setPayAmount(localCurrency - employees.getTaxAmount());
                                employees.setSalary(localCurrency);
                                employees.setType(currency_details.get(j).getType());

                            } else if (localCurrency >= 500000) {
                                employees.setTaxAmount(Math.floor(localCurrency * 0.04));
                                employees.setPayAmount(localCurrency - employees.getTaxAmount());
                                employees.setSalary(localCurrency);
                                employees.setType(currency_details.get(j).getType());
                            }
                        }
                    }

                    Employees employeeCorrected = new Employees(employee_details.get(i).getEmployeeId(), employee_details.get(i).getFullName(), employee_details.get(i).getBranch(), employees.getSalary(), employees.getTaxAmount(), employees.getPayAmount(),employees.getType());
                    details.add(employeeCorrected);

                }
                else if(employee_details.get(i).getEmployeeId().equals(id) && employee_details.get(i).getBranch().equals(new String(" Bangladesh"))){
                    for (int j = 0; j < currency_details.size(); j++) {
                        if (currency_details.get(j).getCountry().equals(new String("Bangladesh"))) {
                            localCurrency = currency_details.get(j).getRate() * employee_details.get(i).getSalary();
                            employees.setTaxAmount(0);
                            employees.setPayAmount(localCurrency);
                            employees.setSalary(localCurrency);
                            employees.setType(currency_details.get(j).getType());
                            Employees employeeCorrected = new Employees(employee_details.get(i).getEmployeeId(), employee_details.get(i).getFullName(), employee_details.get(i).getBranch(), employees.getSalary(), employees.getTaxAmount(), employees.getPayAmount(),employees.getType());
                            details.add(employeeCorrected);

                        }
                    }
                }
            }


        System.out.println(details);
        return details;
    }

}
